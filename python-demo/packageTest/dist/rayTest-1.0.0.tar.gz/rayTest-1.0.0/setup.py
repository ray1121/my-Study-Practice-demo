from distutils.core import setup
setup(name='rayTest',version='1.0.0',py_modules=['hello','world'])