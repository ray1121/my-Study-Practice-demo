# --*-- coding:utf-8 --*--
def printWorld():
	print('World')
