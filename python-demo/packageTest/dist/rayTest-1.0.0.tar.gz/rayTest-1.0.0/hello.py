# --*-- coding:utf-8 --*--
def printHello():
	print('你好')
